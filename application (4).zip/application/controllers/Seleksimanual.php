<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Seleksimanual extends MY_Controller {
    var $column_search = array('nopendaftar','namapendaftar','tempatlahir','tanggallahir','jeniskelamin','suku','jenjangslta','jurusanslta','tahunlulus','asalslta'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    
    public function __construct()
    {
        parent::__construct();
       // $this->load->model('Pendaftar_model','pendaftar');
        $this->load->model('Seleksimanual_model','seleksimanual');
        $this->load->model('Prodi_model','prodi');
    }
 
    public function index()
    {
        $this->ion_auth->is_admin() ? $dd_prodi = $this->prodi->dd_prodi() : $dd_prodi = $this->seleksimanual->dd_prodi();
        $data = array(
			'view' => 'seleksimanual/seleksimanual_view',
			'dd_prodi' => $dd_prodi,
			'prodi_selected' => $this->input->post('pilihprodi') ? $this->input->post('pilihprodi') : '',
        );	
        $this->load->view('layout',$data);
    }
 
    public function ajax_list()
    {
        $list = $this->seleksimanual->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $result) {
            $no++;
           
            $prodipilihan = "";
            if(isset($_POST['is_prodi'])){
                if($_POST['is_prodi']==$result->pilihan1){
                    $prodipilihan = "1 ";
                    if($_POST['is_prodi']==$result->pilihan2){
                        $prodipilihan .= "| 2 ";
                    }
                    if($_POST['is_prodi']==$result->pilihan3){
                        $prodipilihan .= "| 3 ";
                    }
                }
                
                elseif($_POST['is_prodi']==$result->pilihan2){
                    $prodipilihan = "2 ";
                    if($_POST['is_prodi']==$result->pilihan3){
                        $prodipilihan .= "| 3 ";
                    }
                }

                elseif($_POST['is_prodi']==$result->pilihan3){
                    $prodipilihan = "3";
                }
            }
            $row = array(); 
            $result->suku=="P" ? $suku="Papua" : $suku="Non Papua";
            if(date('Y')-$result->tahunlulus>3){
                $row[] = '';
                $row[] = '<font color="red"><strong>'.$result->nopendaftar.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->namapendaftar;
                $row[] = '<font color="red"><center><strong>'.$prodipilihan.'</strong></center></font>';
                $row[] = '<font color="red"><strong>'.$suku.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->nbahasa.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->nipa.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->nips.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->nverbal.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->ratarata.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->tahunlulus.'</strong></font>';
                $row[] = '<font color="red"><strong>'.$result->status.'</strong></font>';
            } else {
                $row[] = '';
                $row[] = $result->nopendaftar;
                $row[] = $result->namapendaftar;
                $row[] = "<center><strong>".$prodipilihan."</strong></center>";
                $row[] = $suku;
                $row[] = $result->nbahasa;
                $row[] = $result->nipa;
                $row[] = $result->nips;
                $row[] = $result->nverbal;
                $row[] = $result->ratarata;
                $row[] = $result->tahunlulus;
                $row[] = $result->status;
            }
            //add html for action
            $row[] = '<a class="btn btn-xs btn-info" href="javascript:void(0)" title="Detail" onclick="detail_record('."'".$result->nopendaftar."'".')"><i class="glyphicon glyphicon-search"></i> Detail</a>
                    <a class="btn btn-xs btn-primary" href="javascript:void(0)" title="Terima" onclick="edit_record('."'".$result->nopendaftar."'".')"><i class="glyphicon glyphicon-ok-circle"></i> Terima</a>';
 
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->seleksimanual->count_all(),
                        "recordsFiltered" => $this->seleksimanual->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
    
}