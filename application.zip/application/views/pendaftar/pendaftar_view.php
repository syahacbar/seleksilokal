<!-- Datatable style -->
<link href="<?php echo base_url('public/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?php echo base_url('public/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
<link href="<?php echo base_url('public/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet">
<link href="<?php echo base_url('public/plugins/select2/select2.min.css')?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url('public/EasyAutocomplete-1.3.5/easy-autocomplete.min.css')?>"> 
<link rel="stylesheet" href="<?php echo base_url('public/EasyAutocomplete-1.3.5/easy-autocomplete.themes.min.css')?>"> 
     
<section class="content"> 
  <div class="box"> 
   <div class="box-header">
     <h3 class="box-title">Master Data Pendaftar</h3>
   </div>
   <!-- /.box-header -->
   <div class="box-body">
        <button class="btn btn-success" onclick="add_record()"><i class="glyphicon glyphicon-plus"></i> Tambah Data</button>
        <button class="btn btn-default" onclick="reload_table()"><i class="glyphicon glyphicon-refresh"></i> Reload</button>
        <button class="btn btn-primary" onclick="import_excel()"><i class="glyphicon glyphicon-import"></i> Import Excel</button>
        <div class="box-body table-responsive">
        <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th width="20px">No</th>
                    <th>No. Peserta</th>
                    <th>Nama Peserta</th>
                    <th>Asal SLTA</th>
                    <th>Jurusan SLTA</th>
                    <th>Tahun Lulus</th>
                    <th style="width:200px;text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
 
           
        </table>
        </div>
   </div>
   <!-- /.box-body -->
 </div>
 <!-- /.box -->
</section> 

<script src="<?php echo base_url('public/js/jquery-1.11.2.min.js') ?>"></script>
<script src="<?php echo base_url('public/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('public/datatables/js/dataTables.bootstrap.js')?>"></script>
<script src="<?php echo base_url('public/bootstrap-datepicker/js/bootstrap-datepicker.min.js')?>"></script>
<script src="<?php echo base_url('public/plugins/select2/select2.full.min.js')?>"></script>
<script src="<?php echo base_url('public/EasyAutocomplete-1.3.5/jquery.easy-autocomplete.min.js')?>"></script> 
<script type="text/javascript">
 
var save_method; //for save method string
var table;

$(document).ready(function() {
    $("#mnpendaftar").addClass('active');
    //datatables
    table = $('#table').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('pendaftar/ajax_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ -1 ], //last column
            "orderable": false, //set not orderable
        },
        ],
 
    });
 
var options = {
    url: function(phrase) {
        return "<?php echo base_url('pendaftar/asalslta/')?>";
    },
    getValue: "namasekolah",
    list: {
        match: {
            enabled: true
        }
    }
};
$("#asalslta").easyAutocomplete(options);   
$('div.easy-autocomplete').removeAttr('style');
 
});
 

function add_record()
{
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('#modal_form').modal('show'); // show bootstrap modal
    $('.modal-title').text('Tambah Pendaftar'); // Set Title to Bootstrap modal title

    

    //Date picker
    $('#datepicker').datepicker({
        format:"dd-mm-yyyy",
        autoclose: true,
        })
    // select2
    $('.select2').select2({
        tags: true
    });

    $("#error_namapendaftar").html('');
    $("#error_tempatlahir").html('');
    $("#error_tanggallahir").html('');
    $("#error_jeniskelamin").html('');
    $("#error_suku").html('');
    $("#error_pilihan1").html('');
    $("#error_pilihan2").html('');
    $("#error_pilihan3").html('');
    $("#error_jenjangslta").html('');
    $("#error_jurusanslta").html('');
    $("#error_asalslta").html('');
    $("#error_tahunlulus").html('');
    $("#error_nbahasa").html('');
    $("#error_nipa").html('');
    $("#error_nips").html('');
    $("#error_nverbal").html('');


     //Ajax Load data from ajax
     $.ajax({
        url : "<?php echo base_url('pendaftar/ajax_get/')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="nopendaftar"]').val(data.nopendaftar);
            $('[name="status"]').val(data.status);
            $('[name="tahunakademik"]').val(data.tahunakademik);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function detail_record(id)
{ 
    save_method = 'detail';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string

    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url('pendaftar/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="nopendaftar"]').val(data.nopendaftar);
            $('[name="namapendaftar"]').val(data.namapendaftar);
            $('[name="ttl"]').val(data.tempatlahir+", "+data.tanggallahir);
            $('[name="tanggallahir"]').val(data.tanggallahir);

            var jk = data.jeniskelamin;
            var suku = data.suku;
            if (jk=='L') jk='LAKI-LAKI'; else  jk='PEREMPUAN';
            if (suku=='P') jk='PAPUA'; else  jk='NON PAPUA';
            
            $('[name="jeniskelamin"]').val(jk);
            $('[name="suku"]').val(data.suku);
            $('[name="pilihan1"]').val(data.pilihan1);
            $('[name="pilihan2"]').val(data.pilihan2);        
            $('[name="pilihan3"]').val(data.pilihan3);
            $('[name="jenjangslta"]').val(data.jenjangslta);
            $('[name="jurusanslta"]').val(data.jurusanslta);        
            $('[name="asalslta"]').val(data.asalslta);        
            $('[name="tahunlulus"]').val(data.tahunlulus);
            $('[name="nbahasa"]').val(data.nbahasa);
            $('[name="nipa"]').val(data.nipa);
            $('[name="nips"]').val(data.nips);
            $('[name="nverbal"]').val(data.nverbal);
            $('[name="status"]').val(data.status);
            $('[name="tahunakademik"]').val(data.tahunakademik);
            $('.modal-title').text('Data Pendaftar'); // Set title to Bootstrap modal title
            $('#modal_detail').modal('show'); // show bootstrap modal when complete loaded
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function edit_record(id)
{
    save_method = 'update';
    
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    //Date picker
    $('#datepicker').datepicker({
        format:"dd-mm-yyyy",
        autoclose: true,
        })
    // select2
    $('.select2').select2({
        tags: true
    });

   

    $("#error_namapendaftar").html('');
    $("#error_tempatlahir").html('');
    $("#error_tanggallahir").html('');
    $("#error_jeniskelamin").html('');
    $("#error_suku").html('');
    $("#error_pilihan1").html('');
    $("#error_pilihan2").html('');
    $("#error_pilihan3").html('');
    $("#error_jenjangslta").html('');
    $("#error_jurusanslta").html('');
    $("#error_asalslta").html('');
    $("#error_tahunlulus").html('');
    $("#error_nbahasa").html('');
    $("#error_nipa").html('');
    $("#error_nips").html('');
    $("#error_nverbal").html('');
 
    //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo base_url('pendaftar/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            $('[name="nopendaftar"]').val(data.nopendaftar);
            $('[name="namapendaftar"]').val(data.namapendaftar);
            $('[name="tempatlahir"]').val(data.tempatlahir);
            $('[name="tanggallahir"]').val(data.tanggallahir);
            $("#datepicker").datepicker( "setDate" , data.tanggallahir );
            
            if (data.jeniskelamin == 'L')
                $("#jeniskelaminL").prop("checked",true);
            else 
                $("#jeniskelaminP").prop("checked",true);
            
            if (data.suku == 'P')
                $("#sukuP").prop("checked",true);
            else 
                $("#sukuNP").prop("checked",true);
            
            $("#pilihan1").val(data.pilihan1).trigger("change");
            $("#pilihan2").val(data.pilihan2).trigger("change");
            $("#pilihan3").val(data.pilihan3).trigger("change");
            $("#jenjangslta").val(data.jenjangslta).trigger("change");
            $("#jurusanslta").val(data.jurusanslta).trigger("change");           
            $('[name="asalslta"]').val(data.asalslta);            
            $('[name="tahunlulus"]').val(data.tahunlulus);
            $('[name="nbahasa"]').val(data.nbahasa);
            $('[name="nipa"]').val(data.nipa);
            $('[name="nips"]').val(data.nips);
            $('[name="nverbal"]').val(data.nverbal);
            $('[name="status"]').val(data.status);
            $('[name="tahunakademik"]').val(data.tahunakademik);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Ubah Data Pendaftar'); // Set title to Bootstrap modal title
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}
 
function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}
 
function save()
{
    
    $("#error_namapendaftar").html('');
    $("#error_tempatlahir").html('');
    $("#error_tanggallahir").html('');
    $("#error_jeniskelamin").html('');
    $("#error_suku").html('');
    $("#error_pilihan1").html('');
    $("#error_pilihan2").html('');
    $("#error_pilihan3").html('');
    $("#error_jenjangslta").html('');
    $("#error_jurusanslta").html('');
    $("#error_asalslta").html('');
    $("#error_tahunlulus").html('');
    $("#error_nbahasa").html('');
    $("#error_nipa").html('');
    $("#error_nips").html('');
    $("#error_nverbal").html('');
    
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 
    if(save_method == 'add') {
        url = "<?php echo site_url('pendaftar/ajax_add')?>";
    } else {
        url = "<?php echo site_url('pendaftar/ajax_update')?>";
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data)
        {
            if (data.hasil !== "sukses") {
                $("#error_namapendaftar").html(data.error.namapendaftar);
                $("#error_tempatlahir").html(data.error.tempatlahir);
                $("#error_tanggallahir").html(data.error.tanggallahir);
                $("#error_jeniskelamin").html(data.error.jeniskelamin);
                $("#error_suku").html(data.error.suku);
                $("#error_pilihan1").html(data.error.pilihan1);
                $("#error_pilihan2").html(data.error.pilihan2);
                $("#error_pilihan3").html(data.error.pilihan3);
                $("#error_jenjangslta").html(data.error.jenjangslta);
                $("#error_jurusanslta").html(data.error.jurusanslta);
                $("#error_asalslta").html(data.error.asalslta);
                $("#error_tahunlulus").html(data.error.tahunlulus);
                $("#error_nbahasa").html(data.error.nbahasa);
                $("#error_nipa").html(data.error.nipa);
                $("#error_nips").html(data.error.nips);
                $("#error_nverbal").html(data.error.nverbal);
            }
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('#modal_form').modal('hide');
                reload_table();
            }
 
            $('#btnSave').text('Simpan'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('Simpan'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}
 
function delete_record(id)
{
    if(confirm('Apakah anda yakin akan menghapus data?'))
    {
        // ajax delete data to database
        $.ajax({
            url : "<?php echo base_url('pendaftar/ajax_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
                //if success reload ajax table
                $('#modal_form').modal('hide');
                reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });
 
    }
}

function import_excel()
{
    save_method = 'import';
    $('#modal_import').modal('show'); // show bootstrap modal
    $('.modal-title').text('Import Data Pendaftar Dari File Excel'); // Set Title to Bootstrap modal title
}


</script>
 
<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Form Pendaftar/h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">No. Pendaftar</label>
                            <div class="col-md-9">
                                <input name="nopendaftar"  class="form-control" type="text" readonly="readonly">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama Pedaftar</label>
                            <div class="col-md-9">
                                <input name="namapendaftar" placeholder="Nama Pendaftar" class="form-control" type="text">
                                <span class="text-danger" id="error_namapendaftar"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tempat, Tgl. Lahir</label>
                            <div class="col-md-5">
                                <input name="tempatlahir" placeholder="Tempat Lahir" class="form-control" type="text">
                                <span class="text-danger" id="error_tempatlahir"></span>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="glyphicon glyphicon-calendar"></i>
                                </div>
                                <input name="tanggallahir" type="text" placeholder="Tgl. Lahir" class="form-control pull-right" id="datepicker">
                                </div>
                                <span class="text-danger" id="error_tanggallahir"></span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-9">
                            <input type="radio" name="jeniskelamin" class="minimal" value="L" id="jeniskelaminL"> LAKI-LAKI
                            <input type="radio" name="jeniskelamin" class="minimal" value="P" id="jeniskelaminP"> PEREMPUAN
                            <span class="text-danger" id="error_jeniskelamin"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Suku</label>
                            <div class="col-md-9">
                                <input type="radio" name="suku" class="minimal" value="P" id="sukuP"> PAPUA
                                <input type="radio" name="suku" class="minimal" value="NP" id="sukuNP"> NON PAPUA
                                <span class="text-danger" id="error_suku"></span>
                            </div>
                        </div> 
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 1</label>
                            <div class="col-md-9">
                            <?php echo form_dropdown('pilihan1', $dd_prodi, $p1_selected,'id="pilihan1" class="form-control select2" style="width: 100%;"'); ?>
                            <span class="text-danger" id="error_pilihan1"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 2</label>
                            <div class="col-md-9">
                            <?php echo form_dropdown('pilihan2', $dd_prodi, $p2_selected,'id="pilihan2" class="form-control select2" style="width: 100%;"'); ?>
                            <span class="text-danger" id="error_pilihan2"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 3</label>
                            <div class="col-md-9">
                            <?php echo form_dropdown('pilihan3', $dd_prodi, $p3_selected,'id="pilihan3" class="form-control select2" style="width: 100%;"'); ?>
                            <span class="text-danger" id="error_pilihan3"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-6">Jenjang SLTA</label>
                            <label class="col-md-6">Jurusan SLTA</label>
                            <div class="col-md-6">
                                <?php echo form_dropdown('jenjangslta', $dd_jenjangslta, $jenjangslta_selected,'id="jenjangslta" class="form-control select2" style="width: 100%;"'); ?>
                                <span class="text-danger" id="error_jenjangslta"></span>
                            </div>
                            <div class="col-md-6">
                                <?php echo form_dropdown('jurusanslta', $dd_jurusanslta, $jurusanslta_selected,'id="jurusanslta" class="form-control select2" style="width: 100%;"'); ?>
                                <span class="text-danger" id="error_jurusanslta"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-9">Asal SLTA</label>
                            <label class="col-md-3">Tahun Lulus</label>
                            <div class="col-md-9">
                                <input name="asalslta" id="asalslta" placeholder="Asal SLTA" class="form-control" type="text">
                                <span class="text-danger" id="error_asalslta"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="tahunlulus" placeholder="Tahun Lulus" class="form-control" type="number">
                                <span class="text-danger" id="error_tahunlulus"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 text-center">Nilai Bahasa</label>
                            <label class="col-md-3 text-center">Nilai IPA</label>
                            <label class="col-md-3 text-center">Nilai IPS</label>
                            <label class="col-md-3 text-center">Nilai Verbal</label>
                        
                            <div class="col-md-3">
                                <input name="nbahasa" placeholder="Nilai Bahasa Indonesia" class="form-control" type="number">
                                <span class="text-danger" id="error_nbahasa"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nipa" placeholder="Nilai IPA" class="form-control" type="number">
                                <span class="text-danger" id="error_nipa"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nips" placeholder="Nilai IPS" class="form-control" type="number">
                                <span class="text-danger" id="error_nips"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nverbal" placeholder="Nilai Verbal" class="form-control" type="number">
                                <span class="text-danger" id="error_nverbal"></span>
                            </div>
                        </div>
                        
                    </div>
                    <input name="status" type="hidden">
                    <input name="tahunakademik" type="hidden">
                                
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Kembali</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->

<!-- Bootstrap modal -->
<div class="modal fade" id="modal_detail" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">Data Pendaftar</h3>
            </div>
            <div class="modal-body form">
                <form action="#" id="form" class="form-horizontal">
                    <div class="form-body">
                        <div class="form-group">
                            <label class="control-label col-md-3">No. Pendaftar</label>
                            <div class="col-md-9">
                                <input name="nopendaftar"  class="form-control" type="text" readonly="readonly">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Nama Pedaftar</label>
                            <div class="col-md-9">
                                <input name="namapendaftar"  readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Tempat, Tgl. Lahir</label>
                            <div class="col-md-5">
                                <input name="ttl"  readonly="readonly" class="form-control" type="text">
                            </div>
                            <div class="col-md-4">
                                <input name="tanggallahir" type="text" readonly="readonly" class="form-control pull-right" id="datepicker">
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-9">
                                <input name="jeniskelamin" id="jeniskelamin" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Suku</label>
                            <div class="col-md-9">
                                <input name="suku" id="suku" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 1</label>
                            <div class="col-md-9">
                                <input name="pilihan1" id="pilihan1" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 2</label>
                            <div class="col-md-9">
                                <input name="pilihan2" id="pilihan2" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3">Pilihan 3</label>
                            <div class="col-md-9">
                                <input name="pilihan3" id="pilihan3" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-6">Jenjang SLTA</label>
                            <label class="col-md-6">Jurusan SLTA</label>
                            <div class="col-md-6">
                                <input name="jenjangslta" id="jenjangslta" readonly="readonly" class="form-control" type="text">
                            </div>
                            <div class="col-md-6">
                            <input name="jurusanslta" id="jurusanslta" readonly="readonly" class="form-control" type="text">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-9">Asal SLTA</label>
                            <label class="col-md-3">Tahun Lulus</label>
                            <div class="col-md-9">
                                <input name="asalslta" id="asalslta" readonly="readonly" class="form-control" type="text">
                                <span class="text-danger" id="error_asalslta"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="tahunlulus" readonly="readonly" class="form-control" type="number">
                                <span class="text-danger" id="error_tahunlulus"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 text-center">Nilai Bahasa</label>
                            <label class="col-md-3 text-center">Nilai IPA</label>
                            <label class="col-md-3 text-center">Nilai IPS</label>
                            <label class="col-md-3 text-center">Nilai Verbal</label>
                        
                            <div class="col-md-3">
                                <input name="nbahasa" readonly="readonly" class="form-control" type="number">
                                <span class="text-danger" id="error_nbahasa"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nipa" readonly="readonly" class="form-control" type="number">
                                <span class="text-danger" id="error_nipa"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nips" readonly="readonly" class="form-control" type="number">
                                <span class="text-danger" id="error_nips"></span>
                            </div>
                            <div class="col-md-3">
                                <input name="nverbal" readonly="readonly" class="form-control" type="number">
                                <span class="text-danger" id="error_nverbal"></span>
                            </div>
                        </div>
                        
                    </div>
                    <input name="status" type="hidden">
                    <input name="tahunakademik" type="hidden">
                                
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Kembali</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- End Bootstrap modal -->
<!-- Modal Import Excel-->
        <div class="modal fade" id="modal_import">
          <div class="modal-dialog">
            <div class="modal-content">
            <?php echo form_open_multipart('pendaftar/importexcel'); ?>
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Default Modal</h4>
              </div>
              <div class="modal-body">
              <?php echo form_upload('file'); ?>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
                <?php echo form_submit('submit','Upload File','class="btn btn-primary"');  ?>
              </div>
              <?php echo form_close(); ?>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
</body>
</html>