<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Seleksimanual extends CI_Controller
{
    function __construct()
    { 
        parent::__construct();
        $this->load->model('Seleksimanual_model');
        $this->load->library('form_validation');        
		$this->load->library('datatables');
    }

    public function index()
    {
		//$this->load->view('seleksimanual/peserta_list');
		$data['view'] = 'seleksimanual/seleksimanual_list';
		$this->load->view('layout', $data);
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Seleksimanual_model->json();
    }

    public function read($id) 
    {
        $row = $this->Seleksimanual_model->get_by_id($id);
        if ($row) {
            $data = array(
		'nopeserta' => $row->nopeserta,
		'namapeserta' => $row->namapeserta,
		'tempatlahir' => $row->tempatlahir,
		'tanggallahir' => $row->tanggallahir,
		'jeniskelamin' => $row->jeniskelamin,
		'suku' => $row->suku,
		'pilihan1' => $row->pilihan1,
		'pilihan2' => $row->pilihan2,
		'pilihan3' => $row->pilihan3,
		'jenjangslta' => $row->jenjangslta,
		'jurusanslta' => $row->jurusanslta,
		'tahunlulus' => $row->tahunlulus,
		'asalslta' => $row->asalslta,
		'nbahasa' => $row->nbahasa,
		'nipa' => $row->nipa,
		'nips' => $row->nips,
		'nverbal' => $row->nverbal,
		'status' => $row->status,
		'tahunakademik' => $row->tahunakademik,
	    );
            $this->load->view('seleksimanual/peserta_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('seleksimanual'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('seleksimanual/create_action'),
	    'nopeserta' => set_value('nopeserta'),
	    'namapeserta' => set_value('namapeserta'),
	    'tempatlahir' => set_value('tempatlahir'),
	    'tanggallahir' => set_value('tanggallahir'),
	    'jeniskelamin' => set_value('jeniskelamin'),
	    'suku' => set_value('suku'),
	    'pilihan1' => set_value('pilihan1'),
	    'pilihan2' => set_value('pilihan2'),
	    'pilihan3' => set_value('pilihan3'),
	    'jenjangslta' => set_value('jenjangslta'),
	    'jurusanslta' => set_value('jurusanslta'),
	    'tahunlulus' => set_value('tahunlulus'),
	    'asalslta' => set_value('asalslta'),
	    'nbahasa' => set_value('nbahasa'),
	    'nipa' => set_value('nipa'),
	    'nips' => set_value('nips'),
	    'nverbal' => set_value('nverbal'),
	    'status' => set_value('status'),
	    'tahunakademik' => set_value('tahunakademik'),
	);
        $this->load->view('seleksimanual/peserta_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'namapeserta' => $this->input->post('namapeserta',TRUE),
		'tempatlahir' => $this->input->post('tempatlahir',TRUE),
		'tanggallahir' => $this->input->post('tanggallahir',TRUE),
		'jeniskelamin' => $this->input->post('jeniskelamin',TRUE),
		'suku' => $this->input->post('suku',TRUE),
		'pilihan1' => $this->input->post('pilihan1',TRUE),
		'pilihan2' => $this->input->post('pilihan2',TRUE),
		'pilihan3' => $this->input->post('pilihan3',TRUE),
		'jenjangslta' => $this->input->post('jenjangslta',TRUE),
		'jurusanslta' => $this->input->post('jurusanslta',TRUE),
		'tahunlulus' => $this->input->post('tahunlulus',TRUE),
		'asalslta' => $this->input->post('asalslta',TRUE),
		'nbahasa' => $this->input->post('nbahasa',TRUE),
		'nipa' => $this->input->post('nipa',TRUE),
		'nips' => $this->input->post('nips',TRUE),
		'nverbal' => $this->input->post('nverbal',TRUE),
		'status' => $this->input->post('status',TRUE),
		'tahunakademik' => $this->input->post('tahunakademik',TRUE),
	    );

            $this->Seleksimanual_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('seleksimanual'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Seleksimanual_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('seleksimanual/update_action'),
		'nopeserta' => set_value('nopeserta', $row->nopeserta),
		'namapeserta' => set_value('namapeserta', $row->namapeserta),
		'tempatlahir' => set_value('tempatlahir', $row->tempatlahir),
		'tanggallahir' => set_value('tanggallahir', $row->tanggallahir),
		'jeniskelamin' => set_value('jeniskelamin', $row->jeniskelamin),
		'suku' => set_value('suku', $row->suku),
		'pilihan1' => set_value('pilihan1', $row->pilihan1),
		'pilihan2' => set_value('pilihan2', $row->pilihan2),
		'pilihan3' => set_value('pilihan3', $row->pilihan3),
		'jenjangslta' => set_value('jenjangslta', $row->jenjangslta),
		'jurusanslta' => set_value('jurusanslta', $row->jurusanslta),
		'tahunlulus' => set_value('tahunlulus', $row->tahunlulus),
		'asalslta' => set_value('asalslta', $row->asalslta),
		'nbahasa' => set_value('nbahasa', $row->nbahasa),
		'nipa' => set_value('nipa', $row->nipa),
		'nips' => set_value('nips', $row->nips),
		'nverbal' => set_value('nverbal', $row->nverbal),
		'status' => set_value('status', $row->status),
		'tahunakademik' => set_value('tahunakademik', $row->tahunakademik),
	    );
            $this->load->view('seleksimanual/peserta_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('seleksimanual'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('nopeserta', TRUE));
        } else {
            $data = array(
		'namapeserta' => $this->input->post('namapeserta',TRUE),
		'tempatlahir' => $this->input->post('tempatlahir',TRUE),
		'tanggallahir' => $this->input->post('tanggallahir',TRUE),
		'jeniskelamin' => $this->input->post('jeniskelamin',TRUE),
		'suku' => $this->input->post('suku',TRUE),
		'pilihan1' => $this->input->post('pilihan1',TRUE),
		'pilihan2' => $this->input->post('pilihan2',TRUE),
		'pilihan3' => $this->input->post('pilihan3',TRUE),
		'jenjangslta' => $this->input->post('jenjangslta',TRUE),
		'jurusanslta' => $this->input->post('jurusanslta',TRUE),
		'tahunlulus' => $this->input->post('tahunlulus',TRUE),
		'asalslta' => $this->input->post('asalslta',TRUE),
		'nbahasa' => $this->input->post('nbahasa',TRUE),
		'nipa' => $this->input->post('nipa',TRUE),
		'nips' => $this->input->post('nips',TRUE),
		'nverbal' => $this->input->post('nverbal',TRUE),
		'status' => $this->input->post('status',TRUE),
		'tahunakademik' => $this->input->post('tahunakademik',TRUE),
	    );

            $this->Seleksimanual_model->update($this->input->post('nopeserta', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('seleksimanual'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Seleksimanual_model->get_by_id($id);

        if ($row) {
            $this->Seleksimanual_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('seleksimanual'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('seleksimanual'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('namapeserta', 'namapeserta', 'trim|required');
	$this->form_validation->set_rules('tempatlahir', 'tempatlahir', 'trim|required');
	$this->form_validation->set_rules('tanggallahir', 'tanggallahir', 'trim|required');
	$this->form_validation->set_rules('jeniskelamin', 'jeniskelamin', 'trim|required');
	$this->form_validation->set_rules('suku', 'suku', 'trim|required');
	$this->form_validation->set_rules('pilihan1', 'pilihan1', 'trim|required');
	$this->form_validation->set_rules('pilihan2', 'pilihan2', 'trim|required');
	$this->form_validation->set_rules('pilihan3', 'pilihan3', 'trim|required');
	$this->form_validation->set_rules('jenjangslta', 'jenjangslta', 'trim|required');
	$this->form_validation->set_rules('jurusanslta', 'jurusanslta', 'trim|required');
	$this->form_validation->set_rules('tahunlulus', 'tahunlulus', 'trim|required');
	$this->form_validation->set_rules('asalslta', 'asalslta', 'trim|required');
	$this->form_validation->set_rules('nbahasa', 'nbahasa', 'trim|required|numeric');
	$this->form_validation->set_rules('nipa', 'nipa', 'trim|required|numeric');
	$this->form_validation->set_rules('nips', 'nips', 'trim|required|numeric');
	$this->form_validation->set_rules('nverbal', 'nverbal', 'trim|required|numeric');
	$this->form_validation->set_rules('status', 'status', 'trim|required');
	$this->form_validation->set_rules('tahunakademik', 'tahunakademik', 'trim|required');

	$this->form_validation->set_rules('nopeserta', 'nopeserta', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Seleksimanual.php */
/* Location: ./application/controllers/Seleksimanual.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-07-13 15:16:41 */
/* http://harviacode.com */