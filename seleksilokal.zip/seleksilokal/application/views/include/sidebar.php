<?php 
$cur_tab = $this->uri->segment(2)==''?'dashboard': $this->uri->segment(2); 
?>  

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li id="dashboard"><a href="<?= base_url('dashboard'); ?>"><i class="fa fa-laptop"></i> <span>Dashboard</span></a></li>

        <li <?php if ($this->uri->segment(2)=='fakultas' || $this->uri->segment(2)=='prodi' || $this->uri->segment(2)=='peserta') { echo 'class="active"'; } ?>) class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Master Data</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li id="fakultas"><a href="<?= site_url('jenjangslta'); ?>"><i class="fa fa-circle-o"></i> Data Jenjang SLTA</a></li>
            <li id="fakultas"><a href="<?= site_url('jurusanslta'); ?>"><i class="fa fa-circle-o"></i> Data Jurusan SLTA</a></li>
            <li id="fakultas"><a href="<?= site_url('fakultas'); ?>"><i class="fa fa-circle-o"></i> Data Fakultas</a></li>
            <li id="prodi"><a href="<?= site_url('prodi'); ?>"><i class="fa fa-circle-o"></i> Data Prodi</a></li>
            <li id="peserta"><a href="<?= site_url('peserta'); ?>"><i class="fa fa-circle-o"></i> Data Peserta</a></li>
          </ul>
        </li>
        <li <?php if ($this->uri->segment(2)=='seleksimanual' || $this->uri->segment(2)=='seleksiotomatis' ) { echo 'class="active"'; } ?>) class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Seleksi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li id="seleksimanual"><a href="<?= site_url('seleksimanual'); ?>"><i class="fa fa-circle-o"></i> Seleksi Manual</a></li>
            <li id="seleksiotomatis"><a href="<?= site_url('seleksiotomatis'); ?>"><i class="fa fa-circle-o"></i> Seleksi Otomatis</a></li>
          </ul>
        </li>
        <li <?php if ($this->uri->segment(2)=='pesertaditerima' || $this->uri->segment(2)=='rekapitulasi' ) { echo 'class="active"'; } ?>) class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li id="pesertaditerima"><a href="<?= site_url('pesertaditerima'); ?>"><i class="fa fa-circle-o"></i> Mahasiswa Diterima</a></li>
            <li id="rekapitulasi"><a href="<?= site_url('rekapitulasi'); ?>"><i class="fa fa-circle-o"></i> Rekapitulasi</a></li>
          </ul>
        </li>
      </ul>

     


    </section>
    <!-- /.sidebar -->
  </aside>

  
<script>
  $("#<?= $cur_tab; ?>").addClass('active');
</script>
