<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Seleksimanual extends CI_Controller {
 
    public function __construct()
    {
        parent::__construct();
       // $this->load->model('Pendaftar_model','pendaftar');
        $this->load->model('Seleksimanual_model','seleksimanual');
        $this->load->model('Prodi_model','prodi');
    }
 
    public function index()
    {
        $data = array(
			'view' => 'seleksimanual/seleksimanual_view',
			'dd_prodi' => $this->prodi->dd_prodi(),
			'p1_selected' => $this->input->post('prodi1') ? $this->input->post('prodi1') : '',
        );	
        $this->load->view('layout',$data);
    }
 
    public function ajax_list()
    {
        $list = $this->seleksimanual->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $result) {
            $no++;
            $rata = ($result->nbahasa+$result->nipa+$result->nips+$result->nverbal)/4;
            if($rata<=50 && $result->suku=="P"){
                $rata += 0.2*$rata;
            }
			$row = array();
			$row[] = '';
            $row[] = $result->nopendaftar;
            $row[] = $result->namapendaftar;
            $row[] = $result->pilihan1;
            $row[] = $result->pilihan2;
            $row[] = $result->pilihan3;
            $row[] = $result->suku;
            $row[] = $result->nbahasa;
            $row[] = $result->nipa;
            $row[] = $result->nips;
            $row[] = $result->nverbal;
            $row[] = $rata;
            $row[] = $result->tahunlulus;
            $row[] = $result->status;
 
            //add html for action
            $row[] = '<a class="btn btn-xs btn-primary" href="javascript:void(0)" title="Terima" onclick="edit_record('."'".$result->nopendaftar."'".')"><i class="glyphicon glyphicon-ok-circle"></i> Terima</a>';
 
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->seleksimanual->count_all(),
                        "recordsFiltered" => $this->seleksimanual->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
	} 
}